import { createClient } from '@libsql/client';

const db = createClient({
  url: process.env.DATABASE_URL,
  authToken: process.env.TURSO_AUTH_TOKEN,
});

// Test: insert a small image to see if the table works at all
const testBase64 = 'UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA='; // 1x1 white pixel WebP, ~72 bytes base64
const testId = 'test-' + Date.now();

try {
  await db.execute({
    sql: 'INSERT INTO product_images (id, data, size, width, height, createdAt) VALUES (?, ?, ?, ?, ?, ?)',
    args: [testId, testBase64, 72, 1, 1, new Date().toISOString()],
  });
  console.log('✅ Test insert OK! Small image works.');

  // Clean up test
  await db.execute({ sql: 'DELETE FROM product_images WHERE id = ?', args: [testId] });
  console.log('✅ Test cleanup OK.');
} catch (error) {
  console.error('❌ Test insert FAILED:', error.message);
  console.error('Full error:', error);
}

// Now test with a larger payload (50KB base64)
const mediumBase64 = 'A'.repeat(50000);
const mediumId = 'test-medium-' + Date.now();

try {
  await db.execute({
    sql: 'INSERT INTO product_images (id, data, size, width, height, createdAt) VALUES (?, ?, ?, ?, ?, ?)',
    args: [mediumId, mediumBase64, 50000, null, null, new Date().toISOString()],
  });
  console.log('✅ Medium insert OK! 50KB works.');

  await db.execute({ sql: 'DELETE FROM product_images WHERE id = ?', args: [mediumId] });
  console.log('✅ Medium cleanup OK.');
} catch (error) {
  console.error('❌ Medium insert FAILED (50KB):', error.message);
}

// Test with 200KB base64
const largeBase64 = 'A'.repeat(200000);
const largeId = 'test-large-' + Date.now();

try {
  await db.execute({
    sql: 'INSERT INTO product_images (id, data, size, width, height, createdAt) VALUES (?, ?, ?, ?, ?, ?)',
    args: [largeId, largeBase64, 200000, null, null, new Date().toISOString()],
  });
  console.log('✅ Large insert OK! 200KB works.');

  await db.execute({ sql: 'DELETE FROM product_images WHERE id = ?', args: [largeId] });
  console.log('✅ Large cleanup OK.');
} catch (error) {
  console.error('❌ Large insert FAILED (200KB):', error.message);
}
