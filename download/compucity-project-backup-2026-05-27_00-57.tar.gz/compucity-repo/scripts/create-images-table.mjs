import { createClient } from '@libsql/client';

const db = createClient({
  url: process.env.DATABASE_URL,
  authToken: process.env.TURSO_AUTH_TOKEN,
});

// Create product_images table
await db.execute(`
  CREATE TABLE IF NOT EXISTS product_images (
    id TEXT PRIMARY KEY,
    data TEXT NOT NULL,
    size INTEGER NOT NULL,
    width INTEGER,
    height INTEGER,
    createdAt TEXT NOT NULL DEFAULT (datetime('now'))
  )
`);

console.log('product_images table created!');

// Verify
const result = await db.execute("SELECT name FROM sqlite_master WHERE type='table'");
console.log('Tables:', result.rows.map(r => r.name));
