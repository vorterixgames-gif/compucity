# Compucity - Project Status

**Última actualización:** 2026-05-27

## 🏪 Proyecto
- **Nombre:** Compucity - Tu Mundo Digital
- **Tipo:** E-commerce de informática (sin pasarela de pagos, pedidos por WhatsApp)
- **Ubicación:** La Falda, Valle de Punilla, Córdoba, Argentina
- **WhatsApp:** 3517656918

## 🛠️ Stack Tecnológico
- **Framework:** Next.js 16 + TypeScript
- **Estilos:** Tailwind CSS 4 + shadcn/ui
- **Base de datos:** Turso (libSQL) + Prisma ORM
- **Auth:** NextAuth
- **Estado:** Zustand + React Query
- **Deploy:** GitHub → Vercel (auto-deploy on push)

## 🎨 Identidad Visual
- **Verde principal:** #3A8B68
- **Verde oscuro:** #2F6F55
- **Verde claro:** #75AD95
- **Verde 50:** #EFF5F2
- **Verde 100:** #D7E7E0
- **Verde 900:** #1A3E2E
- **Estilo:** Claro, elegante, limpio

## 🖼️ Logo
- **Archivo:** `public/images/logo-compucity-icon.png` (191x180px, recortado sin padding transparente)
- **Componente:** `src/components/ui-custom/CompucityLogo.tsx`
  - Variantes: full (icono + COMPU+CITY + tagline), icon, horizontal
  - Tamaños: sm(30px), md(36px), lg(42px), xl(48px) para el ícono
  - Gap: gap-1.5 (6px) entre ícono y texto
  - Texto: "COMPU" en color texto + "CITY" en verde #3A8B68
  - Tagline: "TU MUNDO DIGITAL"

## 📄 Favicon
- `/public/favicon.ico` (16, 32, 48, 64px)
- `/public/favicon-32x32.png`
- `/public/favicon-16x16.png`
- `/public/apple-touch-icon.png` (180x180)
- `/public/android-chrome-192x192.png` (192x192)

## 🏠 Hero Section — Carrusel Full-Width
- **Componente:** `src/components/ui-custom/HeroSection.tsx`
- **Tipo:** Carrusel full-width con 4 slides y autoplay (5s)
- **Navegación:** Flechas laterales, dots indicadores, swipe táctil, teclado (←→)
- **Barra de progreso** animada en la parte inferior
- **Pausa automática** al hacer hover
- **Animaciones:** Framer Motion (slide transitions + fade-up de contenido)
- **Sin info de pagos ni envíos** en el hero (a petición del cliente)

### Slides
| # | Badge | Título | CTA Principal | CTA Secundario | Imagen |
|---|-------|--------|---------------|----------------|--------|
| 1 | Armá tu PC | Armá tu PC **gamer** | Comenzar a armar → `/arma-tu-pc` | Ver componentes → `/categoria/componentes` | `hero-slide-pc-builder.png` |
| 2 | Notebooks | Notebooks y **laptops** | Ver notebooks → `/categoria/notebooks` | Ver todas las marcas → `/categoria/todos` | `hero-slide-notebooks.png` |
| 3 | Componentes | Placas de video y **componentes** | Ver componentes → `/categoria/componentes` | Ver productos → `/categoria/todos` | `hero-slide-components.png` |
| 4 | Periféricos | Periféricos **gaming** | Ver periféricos → `/categoria/perifericos` | Ver todo → `/categoria/todos` | `hero-slide-perifericos.png` |

### Imágenes del Hero
- `public/images/hero-slide-pc-builder.png` — PC gaming con RGB
- `public/images/hero-slide-notebooks.png` — Notebook premium
- `public/images/hero-slide-components.png` — Placa de video / GPU
- `public/images/hero-slide-perifericos.png` — Teclado y mouse gaming
- `public/images/pcb-pattern.svg` — Patrón PCB (uso legacy, ya no en hero)
- `public/images/circuit-pattern.svg` — Patrón circuito (uso legacy)

## 📁 Estructura Key Files
```
src/app/page.tsx              — Home (Hero Carrusel + Productos)
src/app/layout.tsx            — Layout con favicon metadata
src/app/globals.css           — Variables CSS, paleta #3A8B68
src/components/ui-custom/HeroSection.tsx  — Hero Carrusel (4 slides, autoplay)
src/components/ui-custom/CompucityLogo.tsx — Logo componente
src/components/layout/Navbar.tsx  — Nav con logo xl
src/components/layout/Footer.tsx  — Footer con logo lg whiteText
src/components/layout/WhatsAppButton.tsx — Botón flotante
tailwind.config.ts            — Paleta Compucity
public/images/hero-slide-*.png — Imágenes del carrusel hero
public/images/logo-compucity-icon.png — Logo recortado
public/images/pcb-pattern.svg — Patrón PCB (legacy)
```

## 🔗 Repositorio
- **GitHub:** https://github.com/vorterixgames-gif/compucity
- **Vercel:** Auto-deploy desde main

## 📦 Backups
- `/home/z/my-project/download/backups/compucity-backup-2026-05-27_04-35.tar.gz` (13MB)

## 📝 Historial de Cambios
- **2026-05-27:** Rediseño del Hero — de sección estática a carrusel full-width con 4 slides (inspirado en análisis de competencia: Gaming City, Mexx, FullH4rd, CompraGamer, Venex)
- **2026-05-27:** Deploy inicial, logo, favicon, paleta de colores, navbar, footer
