/**
 * Backup de la base de datos Turso → JSON
 * Compucity - Tu Mundo Digital
 * 
 * Uso: node backup-db.mjs
 * 
 * Exporta todas las tablas de la base de datos Turso a un archivo JSON
 * que se guarda en la carpeta /backups/
 */

import { createClient } from '@libsql/client'
import { readFileSync } from 'fs'
import { writeFileSync, mkdirSync, readdirSync, unlinkSync } from 'fs'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

// Cargar .env manualmente
let envConfig = {}
try {
  const envContent = readFileSync(join(__dirname, '.env'), 'utf-8')
  envContent.split('\n').forEach(line => {
    line = line.trim()
    if (line && !line.startsWith('#')) {
      const [key, ...valueParts] = line.split('=')
      if (key && valueParts.length > 0) {
        envConfig[key.trim()] = valueParts.join('=').trim()
      }
    }
  })
} catch (e) {
  console.error('⚠️  No se pudo leer .env, usando variables de entorno del sistema')
}

const DATABASE_URL = envConfig.DATABASE_URL || process.env.DATABASE_URL
const TURSO_AUTH_TOKEN = envConfig.TURSO_AUTH_TOKEN || process.env.TURSO_AUTH_TOKEN

if (!DATABASE_URL || !DATABASE_URL.startsWith('libsql://')) {
  console.error('❌ DATABASE_URL no configurada o no es una URL de Turso')
  process.exit(1)
}

// Crear cliente Turso
const db = createClient({
  url: DATABASE_URL,
  authToken: TURSO_AUTH_TOKEN,
})

// Tablas a respaldar (en orden de dependencia)
const TABLES = [
  'categories',
  'products',
  'admins',
  'orders',
  'order_items',
  'dollar_rates',
  'store_config',
]

async function backupTable(tableName) {
  try {
    const result = await db.execute(`SELECT * FROM ${tableName}`)
    return {
      columns: result.columns,
      rows: result.rows.map(row => {
        // Convertir cada valor a formato serializable
        return result.columns.map(col => {
          const val = row[col]
          if (val === null || val === undefined) return null
          if (typeof val === 'bigint') return val.toString()
          if (val instanceof Date) return val.toISOString()
          return val
        })
      }),
      count: result.rows.length,
    }
  } catch (e) {
    console.warn(`⚠️  Tabla "${tableName}" no encontrada o error: ${e.message}`)
    return { columns: [], rows: [], count: 0 }
  }
}

async function main() {
  console.log('🔄 Conectando a Turso...')
  console.log(`   URL: ${DATABASE_URL}`)
  
  const backup = {
    metadata: {
      timestamp: new Date().toISOString(),
      database: DATABASE_URL,
      version: '1.0',
    },
  }
  
  for (const table of TABLES) {
    console.log(`   Backing up: ${table}...`)
    backup[table] = await backupTable(table)
    console.log(`   ✅ ${table}: ${backup[table].count} registros`)
  }
  
  // Guardar archivo
  const backupDir = join(__dirname, 'backups')
  mkdirSync(backupDir, { recursive: true })
  
  const date = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)
  const filename = `compucity-db-${date}.json`
  const filepath = join(backupDir, filename)
  
  writeFileSync(filepath, JSON.stringify(backup, null, 2), 'utf-8')
  console.log(`\n✅ Backup guardado: ${filepath}`)
  
  // También copiar a /download para acceso fácil
  const downloadDir = join(__dirname, 'download')
  mkdirSync(downloadDir, { recursive: true })
  const downloadPath = join(downloadDir, `compucity-db-backup-${new Date().toISOString().slice(0, 10)}.json`)
  writeFileSync(downloadPath, JSON.stringify(backup, null, 2), 'utf-8')
  console.log(`   Copia en download: ${downloadPath}`)
  
  // Limpiar backups antiguos (mantener últimos 10)
  const files = readdirSync(backupDir)
    .filter(f => f.startsWith('compucity-db-') && f.endsWith('.json'))
    .sort()
    .reverse()
  
  if (files.length > 10) {
    const toDelete = files.slice(10)
    for (const f of toDelete) {
      unlinkSync(join(backupDir, f))
    }
    console.log(`🧹 Eliminados ${toDelete.length} backups antiguos`)
  }
  
  // Resumen
  console.log('\n📊 Resumen del backup:')
  for (const table of TABLES) {
    if (backup[table]) {
      console.log(`   ${table}: ${backup[table].count} registros`)
    }
  }
  
  process.exit(0)
}

main().catch(e => {
  console.error('❌ Error en backup:', e)
  process.exit(1)
})
