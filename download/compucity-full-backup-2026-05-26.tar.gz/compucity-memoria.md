# 🧠 MEMORIA DE PROYECTO — COMPUCITY

## Datos del Proyecto

- **Cliente:** Compucity ("Tu Mundo Digital")
- **Rubro:** Venta de computadoras, componentes y periféricos
- **Ubicación:** La Falda, Valle de Punilla, Córdoba
- **Servicio:** Tienda online con pedidos por WhatsApp
- **Desarrollador:** Gonzalo
- **WhatsApp Gonzalo:** 3517656918
- **Fecha inicio:** Mayo 2026
- **Precio:** $450.000 (único pago, se abona al finalizar)
- **Formas de pago:** Efectivo / Transferencia / 2 cuotas Mercado Pago ($225.000 c/u)
- **Mantenimiento:** 2 primeros meses sin cargo, luego $25.000/mes (opcional, puede variar según dólar)
- **Plazo de entrega:** 4 semanas

---

## Estado del Proyecto

- [x] Propuesta comercial enviada y aceptada
- [x] Reunión de cierre de detalles
- [x] Crear cuenta de Vercel
- [x] Configurar proyecto en Vercel
- [x] Crear base de datos Turso (compucity)
- [x] Crear tablas en Turso con datos iniciales
- [x] Deploy inicial en Vercel
- [ ] Recibir credenciales de APIs de proveedores
- [ ] Recibir fotos y datos de productos
- [ ] Desarrollar tienda online (frontend)
- [ ] Desarrollar panel de administración
- [ ] Integrar sistema de pedidos por WhatsApp (botón que envía resumen de compra)
- [ ] Integrar APIs de proveedores
- [ ] Configurar dominio .com.ar
- [ ] Entrega

---

## Lo que incluye la tienda (según propuesta)

- Catálogo de productos con categorías
- Pedidos por WhatsApp (el cliente envía el pedido directo a los vendedores)
- Panel de administración privado
- Botón de WhatsApp flotante
- Diseño responsive (celular y PC)
- SEO básico en Google
- Google Maps integrado
- Certificado SSL (HTTPS)
- Dominio .com.ar incluido (1er año)
- Hosting incluido
- Soporte post-entrega 60 días
- Cotización del dólar en la tienda

---

## APIs de Proveedores

- Los dueños confirmaron que **tienen proveedores que brindan datos para integrar API**
- **Precio de la integración ya incluido en los $450.000**
- Falta definir:
  - [ ] Nombres de los proveedores
  - [ ] Cómo acceden (token, URL, credenciales)
  - [ ] Formato de los datos (JSON, XML, CSV)
  - [ ] Si incluyen fotos o solo datos
  - [ ] Si muestran stock en tiempo real
  - [ ] Frecuencia de actualización

---

## Funciones del Backend (OBLIGATORIAS)

### Gestión de Productos
- Crear/editar/eliminar productos
- Categorías y subcategorías
- Variaciones de producto (RAM, disco, color)
- Activar/desactivar productos
- Actualización masiva de precios
- Importar desde CSV/API
- Orden de productos (destacados)

### Carrito y Checkout
- Carrito de compras
- Checkout con formulario de datos del cliente
- Botón "Enviar pedido por WhatsApp" que genera mensaje con resumen de compra
- Cálculo de envío según zona
- Confirmación de pedido al cliente (WhatsApp)
- **NO hay pasarela de pagos** — los vendedores coordinan pago y entrega por WhatsApp

### Gestión de Pedidos
- Lista de pedidos recibidos
- Estados: Pendiente → Pagado → En preparación → Enviado → Entregado
- Notificación de pedido nuevo
- Datos del cliente (nombre, teléfono, email, dirección, DNI)
- Detalle del pedido

### Integración con Proveedores
- Conexión con API del proveedor
- Sincronización periódica
- Mapeo de categorías
- Filtro de productos (elegir cuáles publicar)
- Alerta de stock bajo

### Precios y Cotización
- Cotización del dólar visible
- Regla de markup automático (costo + margen = precio venta)
- Precios con/sin IVA

### Envíos
- Zonas de cobertura
- Cálculo automático según código postal
- Métodos: correo, propio, retiro en local
- Campo para número de seguimiento

### Seguridad
- Login del admin
- Certificado SSL (HTTPS)
- Protección de datos del cliente
- Backup automático

---

## Funciones Deseables (NO obligatorias)

- Armado de PC a medida (formulario)
- Cupones de descuento
- Lista de deseos
- Reseñas/opiniones
- Chat en vivo
- Reportes de ventas
- Cuentas de clientes

---

## Preguntas para cerrar en la reunión

### Diseño
- ¿Oscuro gamer o claro profesional?
- Categorías definitivas
- Logo: ¿listo o hay que retocarlo?
- Colores de marca
- ¿Alguna tienda de referencia?

### APIs
- Nombre de cada proveedor
- ¿Cómo acceden? (token, usuario, URL)
- Ejemplo de los datos que reciben
- ¿Incluye fotos?
- ¿Stock en tiempo real?
- ¿Cada cuánto se actualiza?

### Backend
- ¿Cómo manejan el stock? (local + online ¿se descuenta del mismo?)
- ¿Precios con IVA incluido o sin IVA?
- ¿Dólar de referencia? (blue, oficial, mayorista)
- ¿Métodos de envío? (correo, propio, retiro)
- ¿Zonas de envío?
- ¿Costo de envío? (quién lo paga)
- ¿Armado de PC a medida?
- ¿Notificaciones de pedidos? (mail, WhatsApp, ambos)
- ¿Facturación automática o manual?

### Contenido
- Fotos de productos
- Lista de productos inicial
- Descripciones propias o del proveedor
- Datos de contacto (teléfono, dirección, horarios)

### Arranque
- Fecha de inicio
- Plazo para que manden credenciales API
- Plazo para que manden fotos y datos

---

## Mockups Diseñados (Página 4 de la propuesta)

### Diseño general
- **Estilo:** Limpio y moderno, fondo blanco/gris claro
- **Color principal:** Azul brillante (#0099ff) para botones, acentos y logo
- **Logo:** "COMPUCITY" en verde arriba a la izquierda
- **Eslogan:** "Tu Mundo Digital" / "Tu tienda online de electrónica, componentes y más"

### Mockup 1 — Catálogo de productos (vista grid)
- **Header:** Logo Compucity + eslogan
- **Íconos de navegación:** Carrito, perfil de usuario, buscador + botón azul "Iniciar Sesión"
- **Sección "Nuestros Productos"** con pestañas de filtro: Todos, Componentes, Periféricos, Monitores
- **Grilla de productos 2x2** con tarjetas que incluyen:
  - Foto del producto
  - Nombre (ej: "Teclado Mecánico HyperX Alloy FPS", "Laptop HP Pro 14 Intel Core i7")
  - Precio en negrita (ej: $155.750, $260.750)
  - Botón azul "Comprar"

### Mockup 2 — Categoría Componentes y Notebooks (vista lista/tabla)
- **Header:** "Tienda online – Componentes y Notebooks"
- **Botones:** "Filtrar" y "Ordenar" en azul
- **Tabla de productos** con columnas:
  - Nombre del producto
  - Precio
  - Stock (números: 25, 18, etc.)
  - Disponibilidad (checkmarks azules para los que hay stock)
  - Botón "Comprar"

### Productos de ejemplo en los mockups
- Teclado Mecánico HyperX Alloy FPS
- Laptop HP Pro 14 Intel Core i7
- Samsung Galaxy Book Pro 360
- Corsair Vengeance DDR4 16GB
- NVIDIA GeForce RTX 4070 Super

### Pendientes de diseño (a definir en la reunión)
- [ ] Vista de producto individual (fotos grandes, descripción, specs técnicas)
- [ ] Ubicación del botón de WhatsApp flotante
- [ ] Si se muestran cuotas en el precio (ej: "$155.750 o 3 cuotas de $51.917")
- [ ] Diseño de la página del carrito
- [ ] Diseño del checkout con Mobbex
- [ ] Vista mobile (¿cómo se adapta a celular?)

---

## Infraestructura y Costos

### Referencia cambiaria
- **Dólar blue (mayo 2026):** ~$1.430-1.450 ARS

### Escenario 1: Arranque (meses 1-3) — GRATIS
| Servicio | Costo |
|---|---|
| Vercel free | $0 |
| Turso free (9GB, 1B reads) | $0 |
| **Total** | **$0/mes** |

### Escenario 2: Crecimiento (3-6 meses)
| Servicio | USD | ARS (~$1.450) |
|---|---|---|
| DigitalOcean Droplet (app + BD + fotos todo junto) | USD 4/mes | ~$5.800/mes |
| Dominio .com.ar renovación | - | ~$5.000/año |
| **Total** | | **~$6.200/mes** |

### Escenario 3: Mucho crecimiento (6+ meses)
| Servicio | USD | ARS (~$1.450) |
|---|---|---|
| DigitalOcean Droplet más grande | USD 8/mes | ~$11.600/mes |
| Dominio | - | ~$5.000/año |
| **Total** | | **~$12.000/mes** |

### Alternativas económicas de hosting
| Opción | Costo mensual | Qué incluye |
|---|---|---|
| Hostinger VPS | USD 4-6 (~$5.800-8.700) | Server completo |
| DonWeb Hosting | ~$5.000-8.000 ARS | Hosting argentino, soporte en español |
| DigitalOcean Droplet | USD 4 (~$5.800) | VPS rápido, fácil de escalar |
| Cloudways | USD 11 (~$16.000) | Servidor administrado |

### Límites del plan gratis (cuándo hay que pagar)
| Recurso | Límite gratis | Equivale a | Cuándo preocuparse |
|---|---|---|---|
| Vercel | 100GB transferencia/mes | ~8.000-10.000 visitas/mes | Más de 250 visitas/día |
| Supabase BD | 500MB | ~1.500-2.000 productos | Más de 1.500 productos |
| Supabase Storage | 1GB | ~5.000 fotos comprimidas | Más de 1.500 productos con 3 fotos |
| Supabase API | 500.000 requests/mes | Sobra para sync cada 6hs | Solo si sincronizan constantemente |

### Estrategia de upgrade
- Arrancar con todo gratis
- Incluir compresión de imágenes automática en el desarrollo
- Monitorear uso y avisar al cliente cuando se acerque al límite
- Cuando toque pagar → migrar a VPS (todo en uno, más económico)
- El mantenimiento de $25.000/mes cubre cualquier escenario con ganancia

---

## Tráfico estimado (La Falda, Córdoba)

### Contexto
- La Falda: ~15.000 habitantes
- Valle de Punilla: ~100.000-150.000 habitantes
- Zona turística, gente de paso
- La tienda puede vender a todo el país (no solo La Falda)

### Estimaciones por etapa
| Etapa | Visitas/mes | Visitas/día | Cuándo |
|---|---|---|---|
| Lanzamiento | 200-500 | 7-15 | Primeros 2-3 meses |
| Crecimiento | 500-1.500 | 15-50 | Meses 3-6, SEO arrancando |
| Estable | 1.500-3.000 | 50-100 | Después de 6 meses |
| Muy bien | 3.000-5.000 | 100-170 | Con buena presencia en Google |

### Alcance por zona
| Situación | Visitas/mes | Es realista? |
|---|---|---|
| Solo La Falda y Punilla | 1.000-3.000 | ✅ Muy realista |
| Córdoba capital incluida | 3.000-8.000 | ✅ Con buen SEO |
| Todo el país (envíos) | 8.000-20.000 | 🟡 Posible, toma tiempo |
| Explosión viral | 20.000+ | 🟡 Poco probable |

### Conclusión
El plan gratis de Vercel + Supabase alcanza y sobra. Para Compucity en La Falda, es muy difícil superar los 5.000 visitantes/mes en el primer año.

---

## Notas del Desarrollador

- Es la primera vez que Gonzalo hace un proyecto de este tipo
- Los dueños de Compucity no tienen mucho conocimiento técnico
- La API ya está incluida en el precio — no cobrar extra
- Si Gonzalo no sabe algo en la reunión: "Lo reviso y te confirmo"
- Generar backups como .zip cuando Gonzalo lo pida
- Mantener este archivo actualizado con cada avance del proyecto

---

## Historial de Cambios

| Fecha | Cambio |
|---|---|
| 2026-05-22 | Creación del archivo de memoria con toda la info de la propuesta y la reunión |
| 2026-05-22 | Agregado detalle de mockups (página 4): diseño general, vista grid, vista lista, productos de ejemplo, pendientes de diseño |
| 2026-05-22 | Agregado infraestructura y costos: escenarios arranque/crecimiento/mucho crecimiento, alternativas económicas, límites plan gratis, estrategia de upgrade. Dólar blue ~$1.450 |
| 2026-05-22 | Agregado tráfico estimado para La Falda, Córdoba |
| 2026-05-22 | Actualizado estado del proyecto: reunión realizada, arranque con Vercel + Turso |
| 2026-05-22 | Infraestructura configurada: Vercel deploy + Turso DB con 7 tablas + datos iniciales |
| 2026-05-22 | Deploy inicial exitoso: https://my-project-eight-liard-96.vercel.app |
| 2026-05-22 | **CAMBIO IMPORTANTE**: Se elimina Mobbex como pasarela de pagos. El sistema de compras ahora funciona por WhatsApp: el cliente arma su carrito, completa sus datos y envía el pedido directo a los vendedores por WhatsApp. Sin paso de pago online. |
