#!/bin/bash
# ============================================
# Backup de la base de datos Turso → JSON
# Compucity - Tu Mundo Digital
# ============================================
# Uso: ./backup-db.sh
# Genera un archivo JSON con todos los datos de la BD
# ============================================

# Cargar variables de entorno
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/.env" 2>/dev/null

# Configuración
BACKUP_DIR="$SCRIPT_DIR/backups"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/compucity-db-$DATE.json"

# Crear carpeta de backups si no existe
mkdir -p "$BACKUP_DIR"

echo "🔄 Iniciando backup de la base de datos Turso..."
echo "   URL: $DATABASE_URL"

# Ejecutar el script de Node.js para hacer el backup
node "$SCRIPT_DIR/backup-db.mjs"

if [ $? -eq 0 ]; then
    echo "✅ Backup completado exitosamente"
    echo "   Archivo: $BACKUP_FILE"
    
    # Mantener solo los últimos 10 backups
    cd "$BACKUP_DIR"
    ls -t compucity-db-*.json | tail -n +11 | xargs rm -f 2>/dev/null
    echo "🧹 Backups antiguos limpiados (se conservan los 10 más recientes)"
else
    echo "❌ Error al realizar el backup"
    exit 1
fi
