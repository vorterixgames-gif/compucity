# Compucity Admin Panel - Worklog

## Date: 2026-05-22

### Summary
Built a complete admin panel for the Compucity e-commerce store with authentication, CRUD operations for products/categories/orders, dashboard stats, and store configuration.

### Files Created

#### Library
- `src/lib/admin-auth.ts` - Auth helper functions (hash password, verify password, generate slug, generate ID)

#### API Routes
- `src/app/api/admin/auth/login/route.ts` - POST login with email/password, sets admin_token cookie
- `src/app/api/admin/seed/route.ts` - POST to create initial admin user
- `src/app/api/admin/products/route.ts` - GET (list with category join), POST (create), PUT (update), DELETE
- `src/app/api/admin/categories/route.ts` - GET (list), POST (create), PUT (update), DELETE (unlinks products)
- `src/app/api/admin/orders/route.ts` - GET (list with items), PUT (update status/tracking/notes)
- `src/app/api/admin/stats/route.ts` - GET dashboard stats (products, orders, revenue, dollar rate, recent orders)
- `src/app/api/admin/config/route.ts` - GET all config, PUT upsert config values
- `src/app/api/admin/dollar/route.ts` - GET current rate, PUT update rate

#### Admin Layout & Pages
- `src/app/admin/layout.tsx` - Custom layout with dark sidebar, mobile responsive Sheet sidebar, top bar, no public Navbar/Footer
- `src/app/admin/login/page.tsx` - Login form with email/password, eye toggle, error handling
- `src/app/admin/page.tsx` - Dashboard with stats cards, quick actions, recent orders table
- `src/app/admin/productos/page.tsx` - Full CRUD products with search, table, dialog form, delete confirmation
- `src/app/admin/categorias/page.tsx` - Full CRUD categories with parent category support
- `src/app/admin/pedidos/page.tsx` - Orders list with expandable details, status update dialog, tracking number
- `src/app/admin/configuracion/page.tsx` - Store config (name, slogan, whatsapp) + dollar rate update

### Architecture Decisions
- Uses `@libsql/client` directly with raw SQL (matching existing project pattern, NOT Prisma)
- Simple cookie-based auth (admin_token = email) for MVP
- SHA-256 password hashing with salt
- Auto-generated slugs with accent normalization
- Dynamic SQL UPDATE queries (only updates provided fields)
- Category deletion auto-unlinks products (sets categoryId = NULL)
- All text in Spanish (Argentina locale)

### Seed Data
- Admin user created: admin@compucity.com / compucity2026
- Test category "Notebooks" created
- Test product "Notebook Lenovo IdeaPad 3" created
- Dollar rate set to $1,450

### Build Status
- ESLint: PASS (0 errors, 0 warnings)
- Next.js Build: PASS (all 22 routes compiled)
- All API endpoints tested and working
- All admin pages return HTTP 200

---

## Date: 2026-05-27

### Summary: Fixed 5 critical issues in CompuCity

### Issue 1: Orders not saved to DB
- Created `POST /api/orders` endpoint that:
  - Validates required fields (name, phone, items)
  - Validates stock for each product server-side
  - Creates order with orderNumber (CP-XXXXX format)
  - Creates order_items with product references
  - Decrements stock on confirmed orders
  - Returns orderId and orderNumber
- Updated checkout page to call API before WhatsApp
  - Added loading state (spinner + "Guardando pedido...")
  - Added error handling with red alert box
  - If order save fails, WhatsApp doesn't open

### Issue 3: Admin routes unprotected
- Created `src/middleware.ts` with route protection
  - `/admin/login` and `/api/admin/auth/*` are public
  - `/admin/*` pages redirect to login if no cookie
  - `/api/admin/*` routes return 401 if no cookie
  - All other routes pass through

### Issue 4: Images in base64 in DB
- Reviewed the system: images are compressed to WebP client-side, served via `/api/image/[id]` with 1-year cache
- Acceptable for a small catalog (<500 products)
- Future improvement: migrate to Cloudflare R2 when catalog grows

### Issue 5: PC Builder "Finalizar" button did nothing
- Changed onClick from no-op to `window.open(buildWhatsAppUrl(), '_blank')`
- Changed button text from "Finalizar" to "Enviar por WhatsApp"
- Changed icon from Check to MessageCircle

### Issue 6: No server-side stock validation
- Stock validation added in POST /api/orders
- Checks product exists, is active, has sufficient stock
- Returns specific error messages per product
- Client-side already had disabled button when stock <= 0

### Issue 7: What is Prisma?
- Explained to user: it's an ORM that lets you write DB queries as JS objects instead of raw SQL
- In this project it's declared but unused (all queries use @libsql/client directly)
- Not a problem, just a leftover

### Build Status
- Changes committed locally (git push failed - GitHub token lacks permissions for this repo)
- Need user to push manually or provide correct credentials
