import CategoryIcons from '@/components/layout/CategoryIcons'
import BrandLogos from '@/components/layout/BrandLogos'
import ProductCard from '@/components/ui-custom/ProductCard'
import HeroSection from '@/components/ui-custom/HeroSection'
import PromoBanners from '@/components/ui-custom/PromoBanners'
import { getFeaturedProducts, getAllActiveProducts, getTopProductsByCategorySlug } from '@/lib/queries'
import { ensureMigrations } from '@/lib/db'
import Link from 'next/link'
import { Truck, Shield, MessageCircle, Headphones, ArrowRight } from 'lucide-react'

export const dynamic = 'force-dynamic'

function safeParseFirstImage(images: string | null): string | null {
  if (!images) return null
  try { return JSON.parse(images)[0] } catch { return null }
}

export default async function HomePage() {
  // Run auto-migrations (adds shippingDetails column if missing)
  await ensureMigrations()

  let featured: any[] = []
  let allProducts: any[] = []
  let gamerPCs: any[] = []
  let monitorProducts: any[] = []
  let notebookProducts: any[] = []

  try {
    [featured, allProducts, gamerPCs, monitorProducts, notebookProducts] = await Promise.all([
      getFeaturedProducts(),
      getAllActiveProducts(),
      getTopProductsByCategorySlug('pc-armadas', 4),
      getTopProductsByCategorySlug('monitores', 4),
      getTopProductsByCategorySlug('notebooks', 12),
    ])
    // Pick 4 notebooks with brand/line variety (avoid 4 identical Legion)
    if (notebookProducts.length > 4) {
      const seen = new Set<string>()
      const diverse: any[] = []
      for (const p of notebookProducts) {
        const name = (p.name || '').toLowerCase()
        // Extract brand+line as key (e.g. "lenovo legion", "msi cyborg", "lenovo loq", "lenovo t14")
        const brandLine = name.match(/(lenovo\s\w+|msi\s\w+|asus\s\w+|hp\s\w+|dell\s\w+|acer\s\w+)/)?.[1] || name.slice(0, 20)
        if (!seen.has(brandLine)) {
          seen.add(brandLine)
          diverse.push(p)
        }
        if (diverse.length >= 4) break
      }
      notebookProducts = diverse.length >= 4 ? diverse : notebookProducts.slice(0, 4)
    }
  } catch (error) {
    console.error('Homepage data fetch error:', error)
  }

  return (
    <div>
      {/* ==========================================
          TOP BANNERS (above hero)
          ========================================== */}
      <PromoBanners position="top" />

      {/* ==========================================
          HERO - Carrusel Full-Width
          ========================================== */}
      <HeroSection />

      {/* ==========================================
          BELOW-HERO BANNERS
          ========================================== */}
      <PromoBanners position="below-hero" />

      {/* ==========================================
          BENEFITS BAR
          ========================================== */}
      <section className="bg-gradient-to-r from-compucity-green-50 via-compucity-green-100 to-compucity-green-50 border-y border-compucity-green-200/50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { icon: Truck, label: 'Envíos a todo el país' },
              { icon: Shield, label: 'Compra segura' },
              { icon: MessageCircle, label: 'Pedidos por WhatsApp' },
              { icon: Headphones, label: 'Asesoramiento personalizado' },
            ].map((item, i) => {
              const Icon = item.icon
              return (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-white flex items-center justify-center shrink-0 shadow-sm border border-compucity-green-100">
                    <Icon className="h-5 w-5 text-compucity-green-600" />
                  </div>
                  <span className="text-sm text-compucity-green-900 font-semibold">{item.label}</span>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Brand Logos */}
      <BrandLogos />

      {/* Category Icons */}
      <CategoryIcons />

      {/* ==========================================
          ROW 1 - PC Armadas
          ========================================== */}
      {gamerPCs.length > 0 && (
        <section className="py-10 bg-gradient-to-b from-white to-compucity-green-50/50">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-3">
                <div className="w-1 h-8 bg-compucity-green-500 rounded-full" />
                <h2 className="text-2xl md:text-3xl font-bold text-compucity-green-900">PC Armadas</h2>
              </div>
              <Link href="/categoria/pc-armadas" className="inline-flex items-center gap-1 text-sm text-compucity-green-600 hover:text-compucity-green-800 font-semibold group transition">
                Ver todas <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-0.5 transition-transform" />
              </Link>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-5">
              {gamerPCs.map((product) => (
                <ProductCard key={product.id} id={product.id} name={product.name} slug={product.slug} price={product.price} comparePrice={product.comparePrice} image={safeParseFirstImage(product.images)} stock={product.stock} salePrice={product.salePrice} saleStart={product.saleStart} saleEnd={product.saleEnd} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ==========================================
          ROW 2 - Monitores
          ========================================== */}
      {monitorProducts.length > 0 && (
        <section className="py-10 bg-compucity-green-900">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-3">
                <div className="w-1 h-8 bg-compucity-green-400 rounded-full" />
                <h2 className="text-2xl md:text-3xl font-bold text-white">Monitores</h2>
              </div>
              <Link href="/categoria/monitores" className="inline-flex items-center gap-1 text-sm text-compucity-green-300 hover:text-compucity-green-200 font-semibold group transition">
                Ver todas <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-0.5 transition-transform" />
              </Link>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-5">
              {monitorProducts.map((product) => (
                <ProductCard key={product.id} id={product.id} name={product.name} slug={product.slug} price={product.price} comparePrice={product.comparePrice} image={safeParseFirstImage(product.images)} stock={product.stock} salePrice={product.salePrice} saleStart={product.saleStart} saleEnd={product.saleEnd} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ==========================================
          ROW 3 - Notebooks
          ========================================== */}
      {notebookProducts.length > 0 && (
        <section className="py-10 bg-gradient-to-b from-compucity-green-50/30 to-white">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-3">
                <div className="w-1 h-8 bg-compucity-green-500 rounded-full" />
                <h2 className="text-2xl md:text-3xl font-bold text-compucity-green-900">Notebooks</h2>
              </div>
              <Link href="/categoria/notebooks" className="inline-flex items-center gap-1 text-sm text-compucity-green-600 hover:text-compucity-green-800 font-semibold group transition">
                Ver todas <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-0.5 transition-transform" />
              </Link>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-5">
              {notebookProducts.map((product) => (
                <ProductCard key={product.id} id={product.id} name={product.name} slug={product.slug} price={product.price} comparePrice={product.comparePrice} image={safeParseFirstImage(product.images)} stock={product.stock} salePrice={product.salePrice} saleStart={product.saleStart} saleEnd={product.saleEnd} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ==========================================
          CTA - Fondo verde oscuro con gradiente
          ========================================== */}
      <section className="bg-gradient-to-br from-compucity-green-900 via-compucity-green-800 to-compucity-green-950">
        <div className="max-w-7xl mx-auto px-4 py-14 text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-3 text-white">
            ¿No encontrás lo que buscás?
          </h2>
          <p className="text-compucity-green-200 mb-8 max-w-md mx-auto">Contactanos por WhatsApp y te conseguimos lo que necesitás al mejor precio</p>
          <a
            href="https://wa.me/5493517656918?text=Hola!%20Busco%20un%20producto%20que%20no%20vi%20en%20la%20tienda"
            target="_blank"
            className="inline-flex items-center gap-2 px-8 py-3.5 bg-white hover:bg-compucity-green-50 text-compucity-green-800 font-bold rounded-lg transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            <MessageCircle className="h-5 w-5" />
            Consultar por WhatsApp
          </a>
        </div>
      </section>
    </div>
  )
}
