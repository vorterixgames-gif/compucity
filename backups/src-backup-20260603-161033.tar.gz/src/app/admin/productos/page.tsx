'use client'

import React, { useEffect, useState, useCallback } from 'react'
import {
  Plus,
  Search,
  Pencil,
  Trash2,
  Loader2,
  X,
  Package,
  DollarSign,
  Calculator,
  ImageIcon,
  Download,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Filter,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
// Card & Table components not used - using plain HTML to avoid flex layout issues with overflow scroll
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import ImageUploader from '@/components/ui-custom/ImageUploader'

interface Category {
  id: string
  name: string
  slug: string
  parentId: string | null
  enabled: number
}

interface Product {
  id: string
  name: string
  slug: string
  description: string | null
  price: number
  comparePrice: number | null
  costPrice: number | null
  sku: string | null
  stock: number
  isActive: number
  isFeatured: number
  images: string
  specs: string
  providerId: string | null
  providerSku: string | null
  categoryId: string | null
  categoryName: string | null
  markup: number | null
  cashDiscount: number | null
  ivaRate: number | null
  salePrice: number | null
  saleStart: string | null
  saleEnd: string | null
  _calculated?: boolean
  _dollarRate?: number
  _effectiveMarkup?: number
  _effectiveCashDiscount?: number
  _effectiveIvaRate?: number
  _markupSource?: 'product' | 'category' | 'global'
  _cashDiscountSource?: 'product' | 'category' | 'global'
  _ivaRateSource?: 'product' | 'category' | 'default'
  createdAt: string
  updatedAt: string
}

interface ProductForm {
  name: string
  description: string
  price: string
  comparePrice: string
  costPrice: string
  sku: string
  stock: string
  isActive: boolean
  isFeatured: boolean
  imageUrls: string[]  // Array of image URLs (replaces JSON string)
  specs: string
  providerId: string
  providerSku: string
  categoryId: string
  markup: string       // individual product markup (empty = use global)
  cashDiscount: string  // individual product cash discount (empty = use global)
  ivaRate: string       // IVA percentage (empty = use category/default)
  salePrice: string     // promotional price (empty = no sale)
  saleStart: string     // sale start date (ISO)
  saleEnd: string       // sale end date (ISO)
}

type SortColumn = 'name' | 'categoryName' | 'costPrice' | 'price' | 'comparePrice' | 'stock' | 'isActive'
type SortDirection = 'asc' | 'desc'

interface Filters {
  category: string
  stockStatus: string // 'all' | 'inStock' | 'lowStock' | 'outOfStock'
  activeStatus: string // 'all' | 'active' | 'inactive'
  onSale: string // 'all' | 'yes' | 'no'
}

interface DollarConfig {
  rate: number
  markup: number
  cashDiscount: number
  source: string
}

const emptyForm: ProductForm = {
  name: '',
  description: '',
  price: '',
  comparePrice: '',
  costPrice: '',
  sku: '',
  stock: '0',
  isActive: true,
  isFeatured: false,
  imageUrls: [],
  specs: '{}',
  providerId: '',
  providerSku: '',
  categoryId: '',
  markup: '',
  cashDiscount: '',
  ivaRate: '',
  salePrice: '',
  saleStart: '',
  saleEnd: '',
}

function formatPrice(price: number): string {
  return new Intl.NumberFormat('es-AR', {
    style: 'currency',
    currency: 'ARS',
  }).format(price)
}

export default function AdminProductos() {
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [saving, setSaving] = useState(false)

  // Sorting
  const [sortColumn, setSortColumn] = useState<SortColumn>('name')
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc')

  // Filters
  const [filters, setFilters] = useState<Filters>({
    category: 'all',
    stockStatus: 'all',
    activeStatus: 'all',
    onSale: 'all',
  })
  const [showFilters, setShowFilters] = useState(false)

  // Dialog states
  const [formOpen, setFormOpen] = useState(false)
  const [deleteOpen, setDeleteOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [deletingId, setDeletingId] = useState<string | null>(null)
  const [form, setForm] = useState<ProductForm>(emptyForm)
  const [formError, setFormError] = useState('')

  // Dollar config for price calculation
  const [dollarConfig, setDollarConfig] = useState<DollarConfig | null>(null)
  const [calculatedListPrice, setCalculatedListPrice] = useState<number | null>(null)
  const [calculatedCashPrice, setCalculatedCashPrice] = useState<number | null>(null)
  const [imageUploading, setImageUploading] = useState(false)

  const loadProducts = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/products')
      const data = await res.json()
      if (data.ok) {
        setProducts(data.products as Product[])
        // Also grab the dollar config from the response
        if (data.dollarRate) {
          setDollarConfig({
            rate: data.dollarRate,
            markup: data.markup || 30,
            cashDiscount: data.cashDiscount || 10,
            source: data.dollarSource || 'nacion',
          })
        }
      }
    } catch (error) {
      console.error('Error loading products:', error)
    } finally {
      setLoading(false)
    }
  }, [])

  const loadCategories = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/categories')
      const data = await res.json()
      if (data.ok && data.categories && (data.categories as Category[]).length > 0) {
        setCategories(data.categories as Category[])
      } else {
        // No categories found - try initializing them
        console.log('[productos] No categories found, initializing...')
        const initRes = await fetch('/api/admin/init-categories', { method: 'POST' })
        const initData = await initRes.json()
        if (initData.ok) {
          // Reload categories after initialization
          const res2 = await fetch('/api/admin/categories')
          const data2 = await res2.json()
          if (data2.ok) setCategories(data2.categories as Category[])
        }
      }
    } catch (error) {
      console.error('Error loading categories:', error)
    }
  }, [])

  useEffect(() => {
    loadProducts()
    loadCategories()
  }, [loadProducts, loadCategories])

  // Also fetch dollar config separately for the form
  const fetchDollarConfig = useCallback(async () => {
    try {
      const res = await fetch('/api/dolar')
      const data = await res.json()
      if (data.ok) {
        setDollarConfig({
          rate: data.dollar.rate,
          markup: data.config.markup,
          cashDiscount: data.config.cashDiscount,
          source: data.dollar.source,
        })
      }
    } catch (error) {
      console.error('Error fetching dollar config:', error)
    }
  }, [])

  // Calculate prices when costPrice, markup, cashDiscount, ivaRate, or categoryId changes
  useEffect(() => {
    const costUsd = Number(form.costPrice)
    if (costUsd > 0 && dollarConfig) {
      // 3-tier priority: product individual → category → global
      const selectedCategory = form.categoryId ? categories.find(c => c.id === form.categoryId) : null
      const catMarkup = selectedCategory?.markup != null ? Number(selectedCategory.markup) : null
      const catCashDiscount = selectedCategory?.cashDiscount != null ? Number(selectedCategory.cashDiscount) : null
      const catIvaRate = selectedCategory?.ivaRate != null ? Number(selectedCategory.ivaRate) : null

      const effectiveMarkup = form.markup !== '' ? Number(form.markup) : (catMarkup != null ? catMarkup : dollarConfig.markup)
      const effectiveCashDiscount = form.cashDiscount !== '' ? Number(form.cashDiscount) : (catCashDiscount != null ? catCashDiscount : dollarConfig.cashDiscount)
      const effectiveIvaRate = form.ivaRate !== '' ? Number(form.ivaRate) : (catIvaRate != null ? catIvaRate : 10.5)
      // costUSD × (1+IVA) × (1+markup) × dollarRate
      const listPrice = Math.ceil(costUsd * (1 + effectiveIvaRate / 100) * (1 + effectiveMarkup / 100) * dollarConfig.rate)
      const cashPrice = Math.ceil(costUsd * (1 + effectiveIvaRate / 100) * (1 + (effectiveMarkup - effectiveCashDiscount) / 100) * dollarConfig.rate)
      setCalculatedListPrice(listPrice)
      setCalculatedCashPrice(cashPrice)
      // Auto-fill the price fields
      setForm(prev => ({
        ...prev,
        price: String(listPrice),
        comparePrice: String(cashPrice),
      }))
    } else {
      setCalculatedListPrice(null)
      setCalculatedCashPrice(null)
    }
  }, [form.costPrice, form.markup, form.cashDiscount, form.ivaRate, form.categoryId, categories, dollarConfig])

  // Sorting handler
  const handleSort = (column: SortColumn) => {
    if (sortColumn === column) {
      if (sortDirection === 'asc') setSortDirection('desc')
      else { setSortColumn('name'); setSortDirection('asc') } // 3rd click resets
    } else {
      setSortColumn(column)
      setSortDirection('asc')
    }
  }

  // Sort icon for column headers
  const SortIcon = ({ column }: { column: SortColumn }) => {
    if (sortColumn !== column) return <ArrowUpDown className="w-3.5 h-3.5 text-gray-300" />
    if (sortDirection === 'asc') return <ArrowUp className="w-3.5 h-3.5 text-compucity-green" />
    return <ArrowDown className="w-3.5 h-3.5 text-compucity-green" />
  }

  // Count active filters
  const activeFilterCount = Object.values(filters).filter(v => v !== 'all').length

  // Filter + sort products
  const filteredProducts = (() => {
    let result = products.filter(p =>
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.sku?.toLowerCase().includes(search.toLowerCase()) ||
      p.categoryName?.toLowerCase().includes(search.toLowerCase())
    )

    // Apply filters
    if (filters.category !== 'all') {
      result = result.filter(p => p.categoryId === filters.category)
    }
    if (filters.stockStatus !== 'all') {
      if (filters.stockStatus === 'inStock') result = result.filter(p => p.stock > 5)
      else if (filters.stockStatus === 'lowStock') result = result.filter(p => p.stock > 0 && p.stock <= 5)
      else if (filters.stockStatus === 'outOfStock') result = result.filter(p => p.stock <= 0)
    }
    if (filters.activeStatus !== 'all') {
      if (filters.activeStatus === 'active') result = result.filter(p => p.isActive === 1)
      else if (filters.activeStatus === 'inactive') result = result.filter(p => p.isActive !== 1)
    }
    if (filters.onSale !== 'all') {
      if (filters.onSale === 'yes') result = result.filter(p => p.salePrice != null && p.salePrice > 0)
      else if (filters.onSale === 'no') result = result.filter(p => p.salePrice == null || p.salePrice <= 0)
    }

    // Apply sorting
    result.sort((a, b) => {
      let aVal: any, bVal: any
      switch (sortColumn) {
        case 'name': aVal = a.name.toLowerCase(); bVal = b.name.toLowerCase(); break
        case 'categoryName': aVal = (a.categoryName || '').toLowerCase(); bVal = (b.categoryName || '').toLowerCase(); break
        case 'costPrice': aVal = a.costPrice || 0; bVal = b.costPrice || 0; break
        case 'price': aVal = a.price || 0; bVal = b.price || 0; break
        case 'comparePrice': aVal = a.comparePrice || 0; bVal = b.comparePrice || 0; break
        case 'stock': aVal = a.stock; bVal = b.stock; break
        case 'isActive': aVal = a.isActive; bVal = b.isActive; break
        default: return 0
      }
      if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1
      if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1
      return 0
    })

    return result
  })()

  const handleCreate = () => {
    setEditingId(null)
    setForm(emptyForm)
    setFormError('')
    setCalculatedListPrice(null)
    setCalculatedCashPrice(null)
    fetchDollarConfig()
    setFormOpen(true)
  }

  const handleEdit = (product: Product) => {
    setEditingId(product.id)
    // Parse images from JSON string to array
    let imageUrls: string[] = []
    try {
      imageUrls = product.images ? JSON.parse(product.images) : []
    } catch {
      imageUrls = []
    }
    setForm({
      name: product.name,
      description: product.description || '',
      price: String(product.price),
      comparePrice: product.comparePrice ? String(product.comparePrice) : '',
      costPrice: product.costPrice ? String(product.costPrice) : '',
      sku: product.sku || '',
      stock: String(product.stock),
      isActive: product.isActive === 1,
      isFeatured: product.isFeatured === 1,
      imageUrls,
      specs: product.specs || '{}',
      providerId: product.providerId || '',
      providerSku: product.providerSku || '',
      categoryId: product.categoryId || '',
      markup: product.markup != null ? String(product.markup) : '',
      cashDiscount: product.cashDiscount != null ? String(product.cashDiscount) : '',
      ivaRate: product.ivaRate != null ? String(product.ivaRate) : '',
      salePrice: product.salePrice != null ? String(product.salePrice) : '',
      saleStart: product.saleStart ? product.saleStart.slice(0, 10) : '',
      saleEnd: product.saleEnd ? product.saleEnd.slice(0, 10) : '',
    })
    setFormError('')
    fetchDollarConfig()
    setFormOpen(true)
  }

  const handleDelete = (id: string) => {
    setDeletingId(id)
    setDeleteOpen(true)
  }

  const confirmDelete = async () => {
    if (!deletingId) return
    try {
      await fetch(`/api/admin/products?id=${deletingId}`, { method: 'DELETE' })
      setProducts(prev => prev.filter(p => p.id !== deletingId))
    } catch (error) {
      console.error('Error deleting product:', error)
    }
    setDeleteOpen(false)
    setDeletingId(null)
  }

  const handleSave = async () => {
    setFormError('')
    if (!form.name.trim()) {
      setFormError('El nombre es requerido')
      return
    }

    const hasCostPrice = form.costPrice && Number(form.costPrice) > 0
    const hasManualPrice = form.price && Number(form.price) > 0

    if (!hasCostPrice && !hasManualPrice) {
      setFormError('Debés ingresar el costo en USD o el precio de lista manualmente')
      return
    }

    setSaving(true)
    try {
      const imagesJson = JSON.stringify(form.imageUrls)
      console.log('[productos] Saving with images:', form.imageUrls, '-> JSON:', imagesJson)

      const payload = {
        ...(editingId ? { id: editingId } : {}),
        name: form.name.trim(),
        description: form.description.trim() || null,
        price: hasCostPrice ? calculatedListPrice! : Number(form.price),
        comparePrice: hasCostPrice ? calculatedCashPrice! : (form.comparePrice ? Number(form.comparePrice) : null),
        costPrice: form.costPrice ? Number(form.costPrice) : null,
        sku: form.sku.trim() || null,
        stock: Number(form.stock) || 0,
        isActive: form.isActive,
        isFeatured: form.isFeatured,
        images: imagesJson,
        specs: form.specs,
        providerId: form.providerId.trim() || null,
        providerSku: form.providerSku.trim() || null,
        categoryId: form.categoryId || null,
        markup: form.markup !== '' ? Number(form.markup) : null,
        cashDiscount: form.cashDiscount !== '' ? Number(form.cashDiscount) : null,
        ivaRate: form.ivaRate !== '' ? Number(form.ivaRate) : null,
        salePrice: form.salePrice ? Number(form.salePrice) : null,
        saleStart: form.saleStart || null,
        saleEnd: form.saleEnd || null,
      }

      const res = await fetch('/api/admin/products', {
        method: editingId ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })

      const data = await res.json()
      if (!data.ok) {
        const errorMsg = data.detail ? `${data.error}: ${data.detail}` : (data.error || 'Error al guardar')
        setFormError(errorMsg)
        return
      }

      setFormOpen(false)
      loadProducts()
    } catch (error) {
      setFormError('Error de conexión')
    } finally {
      setSaving(false)
    }
  }

  const updateForm = (field: keyof ProductForm, value: string | boolean) => {
    setForm(prev => ({ ...prev, [field]: value }))
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-compucity-green" />
      </div>
    )
  }

  const hasCostPrice = form.costPrice && Number(form.costPrice) > 0

  return (
    <div className="space-y-6 min-w-0">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Productos</h1>
          <p className="text-sm text-gray-500">{products.length} productos en total</p>
        </div>
        <div className="flex items-center gap-2">
          <a
            href="/api/admin/export/products"
            target="_blank"
          >
            <Button variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              Exportar a Excel
            </Button>
          </a>
          <Button onClick={handleCreate} className="bg-compucity-green hover:bg-compucity-green-dark">
            <Plus className="w-4 h-4 mr-2" />
            Nuevo Producto
          </Button>
        </div>
      </div>

      {/* Search + Filter Bar */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center gap-2">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Buscar por nombre, SKU o categoría..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
          <Button
            variant={showFilters ? 'default' : 'outline'}
            className={showFilters ? 'bg-compucity-green hover:bg-compucity-green-dark' : ''}
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter className="w-4 h-4 mr-2" />
            Filtros
            {activeFilterCount > 0 && (
              <Badge className="ml-2 bg-white text-compucity-green text-xs px-1.5 py-0">{activeFilterCount}</Badge>
            )}
          </Button>
        </div>

        {/* Expandable Filters */}
        {showFilters && (
          <div className="flex flex-wrap items-center gap-3 p-3 bg-gray-50 rounded-lg border">
            <div className="space-y-1">
              <Label className="text-xs text-gray-500">Categoría</Label>
              <Select value={filters.category} onValueChange={(v) => setFilters(prev => ({ ...prev, category: v }))}>
                <SelectTrigger className="w-48 h-8 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas</SelectItem>
                  {categories
                    .filter(c => !c.parentId)
                    .sort((a, b) => a.name.localeCompare(b.name))
                    .map(cat => (
                      <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1">
              <Label className="text-xs text-gray-500">Stock</Label>
              <Select value={filters.stockStatus} onValueChange={(v) => setFilters(prev => ({ ...prev, stockStatus: v }))}>
                <SelectTrigger className="w-40 h-8 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="inStock">En stock (+5)</SelectItem>
                  <SelectItem value="lowStock">Bajo stock (1-5)</SelectItem>
                  <SelectItem value="outOfStock">Sin stock (0)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1">
              <Label className="text-xs text-gray-500">Estado</Label>
              <Select value={filters.activeStatus} onValueChange={(v) => setFilters(prev => ({ ...prev, activeStatus: v }))}>
                <SelectTrigger className="w-36 h-8 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="active">Activos</SelectItem>
                  <SelectItem value="inactive">Inactivos</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1">
              <Label className="text-xs text-gray-500">En oferta</Label>
              <Select value={filters.onSale} onValueChange={(v) => setFilters(prev => ({ ...prev, onSale: v }))}>
                <SelectTrigger className="w-36 h-8 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="yes">En oferta</SelectItem>
                  <SelectItem value="no">Sin oferta</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {activeFilterCount > 0 && (
              <Button
                variant="ghost"
                size="sm"
                className="h-8 text-red-500 hover:text-red-700 mt-4"
                onClick={() => setFilters({ category: 'all', stockStatus: 'all', activeStatus: 'all', onSale: 'all' })}
              >
                <X className="w-3 h-3 mr-1" />
                Limpiar filtros
              </Button>
            )}
          </div>
        )}
      </div>

      {/* Products Table */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm text-gray-500">
          <span>{filteredProducts.length} de {products.length} productos{(search || activeFilterCount > 0) ? ' (filtrados)' : ''}</span>
          {(sortColumn !== 'name' || sortDirection !== 'asc') && (
            <button
              onClick={() => { setSortColumn('name'); setSortDirection('asc') }}
              className="text-xs text-compucity-green hover:underline"
            >
              Restablecer orden
            </button>
          )}
        </div>
      <div className="rounded-xl border shadow-sm bg-card text-card-foreground overflow-hidden">
        <div className="admin-table-wrapper">
          {filteredProducts.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <Package className="w-12 h-12 mx-auto mb-2 opacity-30" />
              <p>No hay productos{search || activeFilterCount > 0 ? ' que coincidan con los filtros' : ''}</p>
            </div>
          ) : (
              <table className="w-full text-sm admin-fixed-table">
                <colgroup>
                  <col style={{ width: '28%' }} />
                  <col style={{ width: '13%' }} />
                  <col style={{ width: '11%' }} />
                  <col style={{ width: '14%' }} />
                  <col style={{ width: '13%' }} />
                  <col style={{ width: '7%' }} />
                  <col style={{ width: '6%' }} />
                  <col style={{ width: '8%' }} />
                </colgroup>
                <thead>
                  <tr className="border-b bg-gray-50/80">
                    <th className="h-10 px-2 text-left align-middle font-medium text-gray-600 cursor-pointer select-none hover:bg-gray-100 transition-colors" onClick={() => handleSort('name')}>
                      <div className="flex items-center gap-1">Nombre <SortIcon column="name" /></div>
                    </th>
                    <th className="h-10 px-2 text-left align-middle font-medium text-gray-600 cursor-pointer select-none hover:bg-gray-100 transition-colors" onClick={() => handleSort('categoryName')}>
                      <div className="flex items-center gap-1">Categoría <SortIcon column="categoryName" /></div>
                    </th>
                    <th className="h-10 px-2 text-right align-middle font-medium text-gray-600 cursor-pointer select-none hover:bg-gray-100 transition-colors" onClick={() => handleSort('costPrice')}>
                      <div className="flex items-center justify-end gap-1">Costo USD <SortIcon column="costPrice" /></div>
                    </th>
                    <th className="h-10 px-2 text-right align-middle font-medium text-gray-600 cursor-pointer select-none hover:bg-gray-100 transition-colors" onClick={() => handleSort('price')}>
                      <div className="flex items-center justify-end gap-1">Precio Lista <SortIcon column="price" /></div>
                    </th>
                    <th className="h-10 px-2 text-right align-middle font-medium text-gray-600 cursor-pointer select-none hover:bg-gray-100 transition-colors" onClick={() => handleSort('comparePrice')}>
                      <div className="flex items-center justify-end gap-1">Efectivo <SortIcon column="comparePrice" /></div>
                    </th>
                    <th className="h-10 px-2 text-center align-middle font-medium text-gray-600 cursor-pointer select-none hover:bg-gray-100 transition-colors" onClick={() => handleSort('stock')}>
                      <div className="flex items-center justify-center gap-1">Stock <SortIcon column="stock" /></div>
                    </th>
                    <th className="h-10 px-2 text-center align-middle font-medium text-gray-600 cursor-pointer select-none hover:bg-gray-100 transition-colors" onClick={() => handleSort('isActive')}>
                      <div className="flex items-center justify-center gap-1">Activo <SortIcon column="isActive" /></div>
                    </th>
                    <th className="h-10 px-2 text-center align-middle font-medium text-gray-600">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProducts.map((product, index) => (
                    <tr key={product.id} className={`hover:bg-muted/50 border-b transition-colors ${index % 2 === 1 ? 'bg-gray-50/50' : ''}`}>
                      <td className="p-2 align-middle">
                        <div className="truncate" title={product.name}>
                          <span className="font-medium text-gray-900">{product.name}</span>
                          {product.sku && (
                            <span className="text-xs text-gray-400 font-mono ml-2">{product.sku}</span>
                          )}
                        </div>
                      </td>
                      <td className="p-2 align-middle">
                        <div className="truncate text-sm text-gray-600" title={product.categoryName || ''}>
                          {product.categoryName || '—'}
                        </div>
                      </td>
                      <td className="p-2 align-middle text-right">
                        {product.costPrice && product.costPrice > 0 ? (
                          <div>
                            <div className="flex items-center justify-end gap-1">
                              <DollarSign className="w-3 h-3 text-compucity-green shrink-0" />
                              <span className="font-medium text-compucity-green">{Number(product.costPrice).toFixed(2)}</span>
                            </div>
                            {(product._calculated || (product as any)._effectiveMarkup != null || (product as any)._effectiveCashDiscount != null || (product as any)._effectiveIvaRate != null) && (
                              <div className="flex items-center justify-end gap-0.5 mt-0.5">
                                {product._calculated && (
                                  <Badge variant="secondary" className="text-[10px] px-1 py-0 bg-compucity-green-50 text-compucity-green shrink-0">A</Badge>
                                )}
                                {(product as any)._markupSource === 'product' && (
                                  <Badge variant="secondary" className="text-[10px] px-1 py-0 bg-blue-50 text-blue-600 shrink-0" title={`Margen individual: ${(product as any)._effectiveMarkup}%`}>M</Badge>
                                )}
                                {(product as any)._markupSource === 'category' && (
                                  <Badge variant="secondary" className="text-[10px] px-1 py-0 bg-indigo-50 text-indigo-600 shrink-0" title={`Margen por categoría: ${(product as any)._effectiveMarkup}%`}>MC</Badge>
                                )}
                                {(product as any)._cashDiscountSource === 'product' && (
                                  <Badge variant="secondary" className="text-[10px] px-1 py-0 bg-amber-50 text-amber-600 shrink-0" title={`Desc. efectivo individual: ${(product as any)._effectiveCashDiscount}%`}>D</Badge>
                                )}
                                {(product as any)._cashDiscountSource === 'category' && (
                                  <Badge variant="secondary" className="text-[10px] px-1 py-0 bg-orange-50 text-orange-600 shrink-0" title={`Desc. efectivo por categoría: ${(product as any)._effectiveCashDiscount}%`}>DC</Badge>
                                )}
                                {(product as any)._ivaRateSource === 'product' && (product as any)._effectiveIvaRate !== 10.5 && (
                                  <Badge variant="secondary" className="text-[10px] px-1 py-0 bg-purple-50 text-purple-600 shrink-0" title={`IVA individual: ${(product as any)._effectiveIvaRate}%`}>I</Badge>
                                )}
                                {(product as any)._ivaRateSource === 'category' && (
                                  <Badge variant="secondary" className="text-[10px] px-1 py-0 bg-violet-50 text-violet-600 shrink-0" title={`IVA por categoría: ${(product as any)._effectiveIvaRate}%`}>IC</Badge>
                                )}
                              </div>
                            )}
                          </div>
                        ) : (
                          <span className="text-gray-400">—</span>
                        )}
                      </td>
                      <td className="p-2 align-middle text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <span className="font-medium text-gray-900">{formatPrice(product.price)}</span>
                          {product.salePrice && product.salePrice > 0 && (() => {
                            const now = new Date()
                            const startOk = !product.saleStart || now >= new Date(product.saleStart)
                            const endOk = !product.saleEnd || now <= new Date(product.saleEnd + 'T23:59:59')
                            return startOk && endOk ? (
                              <Badge className="text-[10px] px-1.5 py-0 bg-orange-100 text-orange-700 border-orange-200 border">OFERTA</Badge>
                            ) : null
                          })()}
                        </div>
                      </td>
                      <td className="p-2 align-middle text-right">
                        {product.comparePrice ? (
                          <div className="text-sm text-green-600 font-medium">
                            {formatPrice(product.comparePrice)}
                          </div>
                        ) : (
                          <span className="text-gray-400">—</span>
                        )}
                      </td>
                      <td className="p-2 align-middle text-center">
                        <Badge
                          variant="secondary"
                          className={product.stock > 5 ? 'bg-green-100 text-green-800' : product.stock > 0 ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'}
                        >
                          {product.stock}
                        </Badge>
                      </td>
                      <td className="p-2 align-middle text-center">
                        <Badge variant="secondary" className={product.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'}>
                          {product.isActive ? 'Sí' : 'No'}
                        </Badge>
                      </td>
                      <td className="p-2 align-middle text-center">
                        <div className="flex items-center justify-center gap-0.5">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(product)}
                            title="Editar"
                            className="h-7 w-7"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(product.id)}
                            title="Eliminar"
                            className="text-red-500 hover:text-red-700 h-7 w-7"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
          )}
        </div>
      </div>
      </div>

      {/* Product Form Dialog */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingId ? 'Editar Producto' : 'Nuevo Producto'}
            </DialogTitle>
          </DialogHeader>

          {formError && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
              {formError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2 space-y-2">
              <Label htmlFor="name">Nombre *</Label>
              <Input
                id="name"
                value={form.name}
                onChange={(e) => updateForm('name', e.target.value)}
                placeholder="Nombre del producto"
              />
            </div>

            <div className="sm:col-span-2 space-y-2">
              <Label htmlFor="description">Descripción</Label>
              <Textarea
                id="description"
                value={form.description}
                onChange={(e) => updateForm('description', e.target.value)}
                placeholder="Descripción del producto"
                rows={3}
              />
            </div>

            {/* === PRICING SECTION === */}
            <div className="sm:col-span-2 border rounded-lg p-4 bg-gray-50/50 space-y-4">
              <div className="flex items-center gap-2 text-sm font-semibold text-gray-700">
                <Calculator className="w-4 h-4" />
                Precios
              </div>

              {/* Cost in USD */}
              <div className="space-y-2">
                <Label htmlFor="costPrice" className="flex items-center gap-1">
                  <DollarSign className="w-4 h-4 text-green-600" />
                  Costo en USD
                </Label>
                <Input
                  id="costPrice"
                  type="number"
                  step="0.01"
                  value={form.costPrice}
                  onChange={(e) => updateForm('costPrice', e.target.value)}
                  placeholder="Ej: 150.00"
                  className="bg-white"
                />
                <p className="text-xs text-compucity-green">
                  Ingresá el costo en dólares y los precios en pesos se calculan automáticamente con la cotización actual.
                </p>
              </div>

              {/* Individual Markup & Discount */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="markup" className="flex items-center gap-1">
                    <Calculator className="w-4 h-4 text-blue-600" />
                    Margen individual (%)
                  </Label>
                  <Input
                    id="markup"
                    type="number"
                    step="1"
                    min="0"
                    max="200"
                    value={form.markup}
                    onChange={(e) => updateForm('markup', e.target.value)}
                    placeholder={dollarConfig ? `Global: ${dollarConfig.markup}%` : 'Ej: 30'}
                    className="bg-white"
                  />
                  <p className="text-xs text-gray-400">
                    Dejar vacío para usar categoría ({(() => {
                      const cat = form.categoryId ? categories.find(c => c.id === form.categoryId) : null
                      return cat?.markup != null ? `cat: ${cat.markup}%` : `global: ${dollarConfig?.markup ?? 30}%`
                    })()})
                  </p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cashDiscount" className="flex items-center gap-1">
                    <Calculator className="w-4 h-4 text-amber-600" />
                    Descuento efectivo individual (%)
                  </Label>
                  <Input
                    id="cashDiscount"
                    type="number"
                    step="1"
                    min="0"
                    max="100"
                    value={form.cashDiscount}
                    onChange={(e) => updateForm('cashDiscount', e.target.value)}
                    placeholder={dollarConfig ? `Global: ${dollarConfig.cashDiscount}%` : 'Ej: 10'}
                    className="bg-white"
                  />
                  <p className="text-xs text-gray-400">
                    Dejar vacío para usar categoría ({(() => {
                      const cat = form.categoryId ? categories.find(c => c.id === form.categoryId) : null
                      return cat?.cashDiscount != null ? `cat: ${cat.cashDiscount}%` : `global: ${dollarConfig?.cashDiscount ?? 10}%`
                    })()})
                  </p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ivaRate" className="flex items-center gap-1">
                    <Calculator className="w-4 h-4 text-purple-600" />
                    IVA (%)
                  </Label>
                  <Select
                    value={form.ivaRate || '_inherit'}
                    onValueChange={(value) => updateForm('ivaRate', value === '_inherit' ? '' : value)}
                  >
                    <SelectTrigger className="bg-white">
                      <SelectValue placeholder="Seleccionar IVA" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="_inherit">Heredar de categoría (default 10,5%)</SelectItem>
                      <SelectItem value="10.5">10,5%</SelectItem>
                      <SelectItem value="21">21%</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-gray-400">
                    {(() => {
                      const cat = form.categoryId ? categories.find(c => c.id === form.categoryId) : null
                      return cat?.ivaRate != null
                        ? `Categoría usa ${cat.ivaRate}%. Seleccioná "Heredar" para usar el de categoría.`
                        : 'Heredar usa 10,5% por defecto. Seleccioná 21% si corresponde.'
                    })()}
                  </p>
                </div>
              </div>

              {/* Calculated prices preview */}
              {hasCostPrice && dollarConfig && (
                <div className="bg-compucity-green-50 border border-compucity-green-100 rounded-lg p-3 space-y-2">
                  <p className="text-sm font-semibold text-compucity-green-dark flex items-center gap-1">
                    <Calculator className="w-4 h-4" />
                    Cálculo automático
                  </p>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <p className="text-compucity-green">Cotización dólar</p>
                      <p className="font-bold text-compucity-green-dark">${dollarConfig.rate.toLocaleString('es-AR')}</p>
                    </div>
                    <div>
                      <p className="text-compucity-green">Margen de ganancia</p>
                      <p className="font-bold text-compucity-green-dark">
                        {form.markup !== '' ? form.markup : (() => {
                          const cat = form.categoryId ? categories.find(c => c.id === form.categoryId) : null
                          return cat?.markup != null ? cat.markup : dollarConfig.markup
                        })()}%
                        {form.markup !== '' && <span className="text-xs font-normal text-blue-600 ml-1">(individual)</span>}
                        {form.markup === '' && (() => {
                          const cat = form.categoryId ? categories.find(c => c.id === form.categoryId) : null
                          return cat?.markup != null ? <span className="text-xs font-normal text-indigo-600 ml-1">(categoría)</span> : null
                        })()}
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <p className="text-compucity-green">Descuento efectivo</p>
                      <p className="font-bold text-compucity-green-dark">
                        {form.cashDiscount !== '' ? form.cashDiscount : (() => {
                          const cat = form.categoryId ? categories.find(c => c.id === form.categoryId) : null
                          return cat?.cashDiscount != null ? cat.cashDiscount : dollarConfig.cashDiscount
                        })()}%
                        {form.cashDiscount !== '' && <span className="text-xs font-normal text-amber-600 ml-1">(individual)</span>}
                        {form.cashDiscount === '' && (() => {
                          const cat = form.categoryId ? categories.find(c => c.id === form.categoryId) : null
                          return cat?.cashDiscount != null ? <span className="text-xs font-normal text-orange-600 ml-1">(categoría)</span> : null
                        })()}
                      </p>
                    </div>
                    <div>
                      <p className="text-compucity-green">IVA</p>
                      <p className="font-bold text-compucity-green-dark">
                        {form.ivaRate !== '' ? form.ivaRate : (() => {
                          const cat = form.categoryId ? categories.find(c => c.id === form.categoryId) : null
                          return cat?.ivaRate != null ? cat.ivaRate : '10.5'
                        })()}%
                        {form.ivaRate !== '' && <span className="text-xs font-normal text-purple-600 ml-1">(individual)</span>}
                        {form.ivaRate === '' && (() => {
                          const cat = form.categoryId ? categories.find(c => c.id === form.categoryId) : null
                          return cat?.ivaRate != null ? <span className="text-xs font-normal text-violet-600 ml-1">(categoría)</span> : null
                        })()}
                      </p>
                    </div>
                  </div>
                  <div className="border-t border-compucity-green-100 pt-2 space-y-1 text-sm">
                    <p className="text-gray-600">
                      USD {Number(form.costPrice).toFixed(2)} × (1 + {form.ivaRate !== '' ? form.ivaRate : (() => { const cat = form.categoryId ? categories.find(c => c.id === form.categoryId) : null; return cat?.ivaRate != null ? cat.ivaRate : '10.5'; })()}%) × (1 + {form.markup !== '' ? form.markup : dollarConfig.markup}%) × ${dollarConfig.rate.toLocaleString('es-AR')} = 
                      <strong className="text-gray-900"> {formatPrice(calculatedListPrice!)}</strong> <span className="text-gray-500">(lista c/IVA)</span>
                    </p>
                    <p className="text-gray-600">
                      USD {Number(form.costPrice).toFixed(2)} × (1 + {form.ivaRate !== '' ? form.ivaRate : (() => { const cat = form.categoryId ? categories.find(c => c.id === form.categoryId) : null; return cat?.ivaRate != null ? cat.ivaRate : '10.5'; })()}%) × (1 + {form.markup !== '' ? form.markup : dollarConfig.markup}% - {form.cashDiscount !== '' ? form.cashDiscount : dollarConfig.cashDiscount}%) × ${dollarConfig.rate.toLocaleString('es-AR')} = 
                      <strong className="text-green-700"> {formatPrice(calculatedCashPrice!)}</strong> <span className="text-gray-500">(efectivo c/IVA)</span>
                    </p>
                  </div>
                  <div className="grid grid-cols-2 gap-3 mt-2">
                    <div className="bg-white rounded-md p-2 text-center border">
                      <p className="text-xs text-gray-500">Precio de lista</p>
                      <p className="font-bold text-gray-900">{formatPrice(calculatedListPrice!)}</p>
                    </div>
                    <div className="bg-white rounded-md p-2 text-center border border-green-200">
                      <p className="text-xs text-gray-500">Precio en efectivo</p>
                      <p className="font-bold text-green-700">{formatPrice(calculatedCashPrice!)}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Manual price fields - shown when no costPrice */}
              {!hasCostPrice && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="price">Precio de lista (ARS) *</Label>
                    <Input
                      id="price"
                      type="number"
                      step="0.01"
                      value={form.price}
                      onChange={(e) => updateForm('price', e.target.value)}
                      placeholder="0.00"
                      className="bg-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="comparePrice">Precio en efectivo (ARS)</Label>
                    <Input
                      id="comparePrice"
                      type="number"
                      step="0.01"
                      value={form.comparePrice}
                      onChange={(e) => updateForm('comparePrice', e.target.value)}
                      placeholder="0.00"
                      className="bg-white"
                    />
                    <p className="text-xs text-gray-400">Precio con descuento para pago en efectivo</p>
                  </div>
                </div>
              )}

              {/* When costPrice is set, show read-only calculated values */}
              {hasCostPrice && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Precio de lista (ARS)</Label>
                    <div className="h-10 px-3 flex items-center bg-gray-100 border rounded-md text-sm text-gray-600">
                      {calculatedListPrice ? formatPrice(calculatedListPrice) : '—'} <span className="ml-2 text-xs text-gray-400">(calculado)</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Precio en efectivo (ARS)</Label>
                    <div className="h-10 px-3 flex items-center bg-gray-100 border rounded-md text-sm text-green-700 font-medium">
                      {calculatedCashPrice ? formatPrice(calculatedCashPrice) : '—'} <span className="ml-2 text-xs text-gray-400">(calculado)</span>
                    </div>
                  </div>
                </div>
              )}

              {/* === PRECIO PROMOCIONAL (Sale Price) === */}
              <div className="border-t pt-4 mt-4">
                <details className="group">
                  <summary className="flex items-center gap-2 text-sm font-semibold text-orange-600 cursor-pointer select-none">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A2 2 0 013 12V7a4 4 0 014-4z" /></svg>
                    Precio Promocional
                    <svg className="w-3.5 h-3.5 transition-transform group-open:rotate-90" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                  </summary>
                  <div className="mt-3 space-y-3">
                    <p className="text-xs text-gray-500">
                      Si se configura un precio de oferta, se mostrará tachado el precio de lista y este precio como el vigente.
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="salePrice" className="flex items-center gap-1">
                          <span className="text-orange-600">Precio oferta (ARS)</span>
                        </Label>
                        <Input
                          id="salePrice"
                          type="number"
                          step="0.01"
                          value={form.salePrice}
                          onChange={(e) => updateForm('salePrice', e.target.value)}
                          placeholder="Ej: 299999"
                          className="bg-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="saleStart">Inicio de oferta</Label>
                        <Input
                          id="saleStart"
                          type="date"
                          value={form.saleStart}
                          onChange={(e) => updateForm('saleStart', e.target.value)}
                          className="bg-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="saleEnd">Fin de oferta</Label>
                        <Input
                          id="saleEnd"
                          type="date"
                          value={form.saleEnd}
                          onChange={(e) => updateForm('saleEnd', e.target.value)}
                          className="bg-white"
                        />
                      </div>
                    </div>
                    {form.salePrice && Number(form.salePrice) > 0 && (
                      <div className="p-2 bg-orange-50 border border-orange-200 rounded-lg text-sm text-orange-700">
                        <strong>Oferta activa:</strong> El precio de {formatPrice(Number(form.salePrice))} se mostrará como precio principal
                        {form.saleStart && form.saleEnd && (
                          <> del {new Date(form.saleStart).toLocaleDateString('es-AR')} al {new Date(form.saleEnd).toLocaleDateString('es-AR')}</>
                        )}
                        {form.saleStart && !form.saleEnd && (
                          <> desde el {new Date(form.saleStart).toLocaleDateString('es-AR')}</>
                        )}
                        {!form.saleStart && form.saleEnd && (
                          <> hasta el {new Date(form.saleEnd).toLocaleDateString('es-AR')}</>
                        )}
                        {!form.saleStart && !form.saleEnd && (
                          <> permanentemente (sin fechas configuradas)</>
                        )}
                      </div>
                    )}
                  </div>
                </details>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="sku">SKU</Label>
              <Input
                id="sku"
                value={form.sku}
                onChange={(e) => updateForm('sku', e.target.value)}
                placeholder="SKU-001"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="stock">Stock</Label>
              <Input
                id="stock"
                type="number"
                value={form.stock}
                onChange={(e) => updateForm('stock', e.target.value)}
                placeholder="0"
              />
            </div>

            {/* Category Selection - Two-level selector */}
            <div className="sm:col-span-2 border rounded-lg p-4 bg-gray-50/50 space-y-3">
              <div className="flex items-center gap-2 text-sm font-semibold text-gray-700">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" /></svg>
                Categoría del Producto
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="parentCategory">Categoría Principal</Label>
                  <Select
                    value={(() => {
                      if (!form.categoryId) return '_none'
                      const selectedCat = categories.find(c => c.id === form.categoryId)
                      if (!selectedCat) return '_none'
                      // If it's a parent category, return its id
                      if (!selectedCat.parentId) return selectedCat.id
                      // If it's a child, return its parent's id
                      return selectedCat.parentId
                    })()}
                    onValueChange={(value) => {
                      if (value === '_none') {
                        updateForm('categoryId', '')
                      } else {
                        // When parent changes, auto-select the first subcategory if available
                        const children = categories
                          .filter(c => c.parentId === value && c.enabled === 1)
                          .sort((a, b) => a.name.localeCompare(b.name))
                        if (children.length > 0) {
                          updateForm('categoryId', children[0].id)
                        } else {
                          // No subcategories - assign to parent directly
                          updateForm('categoryId', value)
                        }
                      }
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccioná una categoría" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="_none">Sin categoría</SelectItem>
                      {categories
                        .filter(c => !c.parentId)
                        .sort((a, b) => a.name.localeCompare(b.name))
                        .map(parent => (
                          <SelectItem key={parent.id} value={parent.id}>
                            {parent.name} {parent.enabled === 0 ? '(oculta)' : ''}
                          </SelectItem>
                        ))
                      }
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="subCategory">Subcategoría</Label>
                  <Select
                    value={form.categoryId && categories.find(c => c.id === form.categoryId)?.parentId ? form.categoryId : '_all'}
                    onValueChange={(value) => {
                      if (value === '_all') {
                        // Keep parent category selected
                        const selectedCat = categories.find(c => c.id === form.categoryId)
                        if (selectedCat?.parentId) {
                          updateForm('categoryId', selectedCat.parentId)
                        }
                      } else {
                        updateForm('categoryId', value)
                      }
                    }}
                    disabled={!form.categoryId || !categories.find(c => c.id === form.categoryId)?.parentId && !categories.find(c => c.id === form.categoryId && categories.some(ch => ch.parentId === c.id))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Todas" />
                    </SelectTrigger>
                    <SelectContent>
                      {(() => {
                        const selectedCat = categories.find(c => c.id === form.categoryId)
                        const parentId = selectedCat?.parentId || selectedCat?.id
                        if (!parentId) return null
                        const parentCat = categories.find(c => c.id === parentId)
                        const children = categories
                          .filter(c => c.parentId === parentId)
                          .sort((a, b) => a.name.localeCompare(b.name))
                        if (children.length === 0) return <SelectItem value="_all">Sin subcategorías</SelectItem>
                        return (
                          <>
                            <SelectItem value="_all">Todas las {parentCat?.name || 'subcategorías'}</SelectItem>
                            {children.map(child => (
                              <SelectItem key={child.id} value={child.id}>
                                {child.name} {child.enabled === 0 ? '(oculta)' : ''}
                              </SelectItem>
                            ))}
                          </>
                        )
                      })()}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              {form.categoryId && (() => {
                const selectedCat = categories.find(c => c.id === form.categoryId)
                if (!selectedCat) return null
                const parentName = selectedCat.parentId
                  ? categories.find(c => c.id === selectedCat.parentId)?.name
                  : selectedCat.name
                const childName = selectedCat.parentId ? selectedCat.name : null
                return (
                  <div className="flex items-center gap-2 text-xs text-gray-500 bg-white border rounded-md px-3 py-2">
                    <span className="font-medium text-compucity-green">
                      {parentName}{childName ? ` › ${childName}` : ''}
                    </span>
                    {selectedCat.enabled === 0 && (
                      <span className="text-amber-600 font-medium">(categoría oculta)</span>
                    )}
                  </div>
                )
              })()}
            </div>

            <div className="space-y-2">
              <Label htmlFor="providerId">ID Proveedor</Label>
              <Input
                id="providerId"
                value={form.providerId}
                onChange={(e) => updateForm('providerId', e.target.value)}
                placeholder="ID del proveedor"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="providerSku">SKU Proveedor</Label>
              <Input
                id="providerSku"
                value={form.providerSku}
                onChange={(e) => updateForm('providerSku', e.target.value)}
                placeholder="SKU del proveedor"
              />
            </div>

            <div className="flex items-center gap-3 py-2">
              <Switch
                id="isActive"
                checked={form.isActive}
                onCheckedChange={(checked) => updateForm('isActive', checked)}
              />
              <Label htmlFor="isActive">Producto activo</Label>
            </div>

            <div className="flex items-center gap-3 py-2">
              <Switch
                id="isFeatured"
                checked={form.isFeatured}
                onCheckedChange={(checked) => updateForm('isFeatured', checked)}
              />
              <Label htmlFor="isFeatured">Producto destacado</Label>
            </div>

            <div className="sm:col-span-2 space-y-2">
              <Label className="flex items-center gap-1">
                <ImageIcon className="w-4 h-4" />
                Imágenes del producto
              </Label>
              <ImageUploader
                images={form.imageUrls}
                onChange={(urls) => {
                  console.log('[productos] ImageUploader onChange:', urls)
                  setForm(prev => ({ ...prev, imageUrls: urls }))
                }}
                maxImages={6}
              />
            </div>

            <div className="sm:col-span-2 space-y-2">
              <Label htmlFor="specs">Especificaciones (JSON)</Label>
              <Textarea
                id="specs"
                value={form.specs}
                onChange={(e) => updateForm('specs', e.target.value)}
                placeholder='{"RAM": "16GB", "Disco": "512GB SSD"}'
                rows={3}
                className="font-mono text-sm"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setFormOpen(false)} disabled={saving}>
              Cancelar
            </Button>
            <Button onClick={handleSave} className="bg-compucity-green hover:bg-compucity-green-dark" disabled={saving || imageUploading}>
              {saving ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Guardando...
                </>
              ) : imageUploading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Subiendo imágenes...
                </>
              ) : (
                editingId ? 'Guardar Cambios' : 'Crear Producto'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar producto?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. El producto será eliminado permanentemente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
